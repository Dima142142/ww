<template>
  <router-view />
</template>

<script>
import './charts/ChartjsConfig';
</script>

